//
//  PhrasesModel.swift
//  youAreApp
//
//  Created by Fabrício Guilhermo on 17/04/20.
//  Copyright © 2020 Fabrício Guilhermo. All rights reserved.
//

import Foundation

struct PhrasesModel {

    static var phrasesList = ["teste1", "teste2", "teste3"]

}
